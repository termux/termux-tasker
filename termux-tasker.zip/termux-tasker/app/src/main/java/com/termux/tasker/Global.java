package com.termux.tasker;

import java.io.File;

/**
 * Global variables
 */
public class Global {
    public static String TASKER_DIRstr="/data/data/com.termux/files/home/.termux/tasker/";
    public static File TASKER_DIR = new File(TASKER_DIRstr);
}
